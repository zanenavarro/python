.. autoclass:: AmazonHelper
  :members:
.. autoclass:: discord_data_class
  :members:
.. autoclass:: RecipeHelper
  :members:
.. autoclass:: EntertainmentHelper
  :members:
.. autoclass:: GymHelper
  :members:
